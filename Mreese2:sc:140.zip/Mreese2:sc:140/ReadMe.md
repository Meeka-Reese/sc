# Tweet Project - Meeka









## Debugging/Development


<p> 
This was my first attempt at creating sound for the project.
</p>

    {k = LFTri.kr(freq: 440.0, iphase: 0.0, mul: 1.0, add: 0.0)
	SinOsc.ar(freq: k)}.play

<p>
The formating of the code ended up being far off from what I needed. First of all, I needed to declare k as a <b> var </b>. I also needed to set a range for the LFO so that the frequency of the SinOsc would be within audible range. This is what I ended up with.
</p>

    {var k = LFTri.kr(Rand(0.1, 5)).exprange(100, 9000);
    SinOsc.ar(k, 0, 0.5);}.play;
<p>
The issue now is that the Rand is only triggered once on start so
I swapped to a LFNoise to trigger new frequencies constantly. 
</p>

    {var k = LFNoise0.kr(5).exprange(100, 9000);
    var a = SinOsc.ar(2*k,0,5000);
    SinOsc.ar(a, 0, 0.5);}.play;
<p>
I was playing around with the patch more and I got this random vomit of frequencies.
</p>

    {var rate = LFNoise0.kr(0.5).exprange(1, 5000);
    var k = LFNoise0.kr(rate).exprange(20, 500);
	var a = SinOscFB.ar(k*k*rate/10,k,3000);
    SinOsc.ar(a, 0, 0.5);}.play;
<p>
But even if I condense it down I'm still at 148 characters :(
</p>
<p>
I Later was able to condense it down below 140 characters, but I wasn't super happy with the sound so I continued on.
</p>

    {k=LFNoise1.kr(8.0.rand+2,0.5,0.5);SinOsc.ar([[333,444],[222,555]]*(k+(rrand(1.0,5.0))),0,k).sum.cubed * 0.1}.play
<p>
I then modified the patch to include a second oscilator that uses the first oscilator as it's frequency. I then use the first oscilator for the frequency of the left SinOsc, and the second for the right. The patch is cool but it ended up waaaaay too long, so now it's time to condense.
</p>

    {var b=LFNoise0.kr(5);var r=LFSaw.kr(b).exprange(1,20);
    var k=LFSaw.kr(r*2).exprange(b,999);
    var a=SinOscFB.ar(k*k*8,r,k);
    var c=SinOscFB.ar(a*5);
    [SinOsc.ar(a),SinOsc.ar(c*50)]}.play;
<p>
After that, I got it down to 160 characters. It sounds nice and glitchy but I still had some room to reduce.
</p>

    {var b=LFNoise0.kr(5);var r=LFSaw.kr(b)*9;
    var k=LFSaw.kr(r).exprange(b,999);
    var a=SinOscFB.ar(k*8,r,k);var c=SinOsc.ar(a*9);
    [SinOsc.ar(a),SinOsc.ar(c*50)]}.play;

<p>
 Here's my final reduction. I ended up being able to reduce the space a lot by putting all the var declaration's in the same line. I was also able to cut down on the space by removing the *8 in the a variable. This made the synth generally darker so I increased the pitch multiplication in c to bring up some more high frequencies. 
 </p>

    {var b=LFNoise0.kr(5),r=LFSaw.kr(b)*9,k=LFSaw.kr(r).range(r,999),a=SinOscFB.ar(k,r,k),c=SinOsc.ar(a*15);[SinOsc.ar(a),SinOsc.ar(c*k)]}.play;

## Final Product Explanation
<p>
So much of the patch is unpredictable and potentially speaker-breaking depending on the level. The patch has 3 general stages. The first stage is the k-rate modulators. In this patch, I have 1 LFNoise and 2 LFSaw's with each of their outputs being fed into the next LFO's pitch. After that, we have the first a-rate stage. This is where I further the modulation by using the final product of the modulation stage and using it as the pitch for var 'a'. After that, I send var 'a' as the pitch-in for the next SinOsc. After that, we have the second a-rate stage. At this last stage, I take the outputs of the two previous a-rate variables and use them as the pitch-ins for two hard-panned SinOscs. I then multiply the right channel SinOsc by k to add modulation and equalize the levels between ears.
</p>